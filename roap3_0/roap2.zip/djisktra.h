#ifndef _DJISKTRA_
#define _DJISKTRA_

void djisktra(int *graph, int L, int C, int* dist, int *parent, bool *sptSet, int src);
int i_idx(int idx, int C);
int j_idx(int idx, int C);

#endif
