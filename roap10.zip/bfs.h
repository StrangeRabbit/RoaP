#ifndef __BFS__
#define __BFS__

void bfs(int *graph, int L, int C, int *room);

#endif