#ifndef PRINT
#define PRINT

#include <stdio.h>

#include "list.h"

void printWalls(_room **list, int *parent, int treasure, FILE *ofp, int C, int walls);

#endif