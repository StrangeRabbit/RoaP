#ifndef _DJISKTRA_
#define _DJISKTRA_

#include "list.h"

void djisktra(_room **graph, int room2, int* dist, int *parent, bool *sptSet, int V);

#endif
