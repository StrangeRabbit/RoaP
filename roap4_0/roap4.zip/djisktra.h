#ifndef _DJISKTRA_
#define _DJISKTRA_

#include "adjacencyList.h"

void djisktra(list **graph, int room2, int* dist, int *parent, bool *sptSet, int V);
int i_idx(int idx, int C);
int j_idx(int idx, int C);

#endif
